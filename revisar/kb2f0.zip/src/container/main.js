import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { add_actions, add } from "../store/actions/actions";
import { ACTIONS_CONSTANT } from "../store/actions/constant";

export const Main = () => {
  const data = useSelector(state => state.actions);
  const dispacth = useDispatch();
  const [values, setValues] = useState({
    id: "",
    name: "",
    completed: false
  });
  const handle_change = e => {
    const t = e.target;
    setValues({
      ...values,
      [t.name]: t.value
    });
  };
  // const handle_agregar = () => {
  //   dispacth(add_actions(values));
  //   setValues({ id: "", name: "", completed: false });
  // };
  const handle_agregar = () => {
    dispacth(add(values));
    setValues({ id: "", name: "", completed: false });
  };
  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div stype={{ display: "flex", flexDirection: "column" }}>
        <input
          type="text"
          name="id"
          placeholder="ID"
          value={values.id}
          onChange={handle_change}
        />
        <input
          type="text"
          name="name"
          placeholder="name"
          value={values.name}
          onChange={handle_change}
        />
        <input
          type="text"
          name="completed"
          placeholder="completed"
          value={values.completed}
          onChange={handle_change}
        />
        <button onClick={handle_agregar}> Agregar</button>
      </div>
      <div>
        {data.map(item => (
          <div
            key={item.id}
            style={{
              display: "flex",
              justifyContent: "center",
              marginBottom: "0px"
              // alignItems: "flex-end"
            }}
          >
            <h3 style={{ marginRight: "6px" }}>{item.id} </h3>
            <h2 style={{ marginRight: "6px" }}> {item.name}</h2>
            <h3> {item.completed ? "completed" : "no completed"} </h3>
          </div>
        ))}
      </div>
      {/* <div>{data}</div> */}
    </div>
  );
};
