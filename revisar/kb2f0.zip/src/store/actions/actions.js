import { ACTIONS_CONSTANT } from "./constant";

export function add_actions(objectX) {
  return {
    type: ACTIONS_CONSTANT.ADD_ACTIONS,
    playload: objectX
  };
}
export function add(objectX) {
  return {
    type: ACTIONS_CONSTANT.ADD,
    playload: objectX
  };
}

export function update_actions(objectX) {
  return {
    type: ACTIONS_CONSTANT.UPDTE_ACTIONS,
    playload: objectX
  };
}

export function delete_actions(objectX) {
  return {
    type: ACTIONS_CONSTANT.ACTIONS_CONSTANT,
    playload: objectX
  };
}
