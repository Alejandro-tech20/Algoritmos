import {} from "../actions/actions";
import { ACTIONS_CONSTANT } from "../actions/constant";

const initialState = {
  actions: [{ id: 1, name: "initial", completed: false }]
};

// Sample Redux reducer
// export const rootReducer = (state = 0, action) => {
//   console.log("Action", action);

//   switch (action.type) {
//     case "INCREMENT":
//       return state + action.playload;
//     default:
//       return state;
//   }
// };

export const rootReducer = (state = initialState, action) => {
  console.log("Action", action);
  switch (action.type) {
    case ACTIONS_CONSTANT.ADD_ACTIONS:
      return Object.assign({}, state, {
        actions: state.actions.concat({
          ...action.playload
        })
      });
    case ACTIONS_CONSTANT.UPDTE_ACTIONS:
      return Object.assign({}, state, {
        actions: state.actions.map(item =>
          item.id === action.playload.id ? { ...item, completed: true } : item
        )
      });
    case ACTIONS_CONSTANT.DELETE_ACTIONS:
      return Object.assign({}, state, {
        actions: state.actions.filter(item => item.id !== action.playload.id)
      });
    default:
      return state;
  }
};
