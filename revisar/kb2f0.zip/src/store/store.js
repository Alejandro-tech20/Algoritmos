import { createStore, applyMiddleware } from "redux";
import { rootReducer } from "./reducer/reducer";
import { createEpicMiddleware } from "redux-observable";
import { filter, map, mergeMap } from "rxjs/operators";
import { ACTIONS_CONSTANT } from "./actions/constant";
import { add_actions } from "./actions/actions";

const countEpic = action$ =>
  action$.pipe(
    filter(action => action.type === ACTIONS_CONSTANT.ADD),
    mergeMap(async action => {
      await new Promise(reso => setTimeout(reso, 1000));
      return add_actions(action.playload);
    })
    // map(action => {
    //   return {
    //     type: "ADD_ACTIONS",
    //     playload: action.playload
    //   };
    // })
  );
const observableMiddleware = createEpicMiddleware();

export const store = createStore(
  rootReducer,
  applyMiddleware(observableMiddleware)
);
observableMiddleware.run(countEpic);
