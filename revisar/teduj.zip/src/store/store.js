import { createStore, applyMiddleware } from "redux";
import { rootReducer } from "./indexReducer";


import {createEpicMiddleware} from 'redux-observable'
import {filter,map} from 'rxjs/operators'

// export const store = createStore(rootReducer);

const count = action$ => action$.pipe(
  filter(action => action.type === 'CLICK_INCREMENT'),
  map(action => {
    return {type: 'INCREMENT', amount:1}
  })
);

const observableMiddleware = createEpicMiddleware()
export const store = createStore(reducer, applyMiddleware(observableMiddleware))

observableMiddleware.run(count);

function reducer(state=0, action){
  console.log('Accion', action);
  switch(action.type){
    case "INCREMENT":
      return state + action.amount;
      default:
        return state
  }
}