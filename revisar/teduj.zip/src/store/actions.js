import { ACTIONS_TYPES } from "./type-actions";

export function addActions(actions) {
  return {
    type: ACTIONS_TYPES.ADD_ACTIONS,
    payload: actions
  };
}

export function toggleActions(actions) {
  return {
    type: ACTIONS_TYPES.TOGGLE_ACTIONS,
    payload: actions
  };
}

export function removeActions(actions) {
  return {
    type: ACTIONS_TYPES.REMOVE_ACTIONS,
    payload: actions
  };
}
