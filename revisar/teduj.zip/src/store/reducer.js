import { ACTIONS_TYPES } from "./type-actions";

const initialState = {
  actions: [
    {
      id: 1,
      name: "initial",
      completed: false
    }
  ]
};

export const actionsReducer = (state = initialState, actions) => {
  switch (actions.type) {
    case ACTIONS_TYPES.ADD_ACTIONS:
      return Object.assign({}, state, {
        actions: state.actions.concat({
          ...actions.payload
        })
      });
    case ACTIONS_TYPES.TOGGLE_ACTIONS:
      return Object.assign({}, state, {
        actions: state.actions.map(act =>
          act.id === actions.payload.id
            ? { ...act, completed: !act.completed }
            : act
        )
      });
    case ACTIONS_TYPES.REMOVE_ACTIONS:
      return {
        actions: state.actions.filter(item => item.id === !actions.payload.id)
      };
    default:
      return state;
  }
};
