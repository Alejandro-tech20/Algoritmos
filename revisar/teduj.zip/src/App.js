import React, { useEffect, useState } from "react";
import "./styles.css";
// import { from, BehaviorSubject } from "rxjs";
// import {
//   filter,
//   mergeMap,
//   debounceTime,
//   distinctUntilChanged,
//   delay
// } from "rxjs/operators";
import { Main } from "./container/main";

// // ==============
// const str = from([1, 2, 3, 4, 5]);
// const ot = str.pipe(
//   mergeMap(r => from([r]).pipe(delay(1000 * r)))
//   // debounceTime(1000)
// );
// ot.subscribe(r => console.log(r),{},()=>console.log('ya'))
// ot.unsubscribe();
// ==============
// const fet = async name => {
//   const { results: allData } = await fetch(
//     "https://pokeapi.co/api/v2/pokemon/?limit=1000"
//   ).then(k => k.json());
//   return allData.filter(r => r.name.includes(name));
// };
// // ==============
// const behavor = new BehaviorSubject("");
// const final = behavor.pipe(
//   filter(r => r.length > 1),
//   debounceTime(700),
//   distinctUntilChanged(),
//   mergeMap(r => from(fet(r)))
// );
// // ==============
// const useObserver = (obser, setter) => {
//   useEffect(() => {
//     const tem = obser.subscribe(re => setter(re));
//     return () => {
//       tem.unsubscribe();
//     };
//   }, [obser, setter]);
// };
// ==============
export default function App() {
  const [state, setState] = useState();
  const [result, setResult] = useState([]);
  // useObserver(final, setResult);
  const handleChange = e => {
    const a = e.target.value;
    setState(a);
    // behavor.next(a);
  };
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>
      <div>
        <input
          type="text"
          placeholder="Search"
          value={state}
          onChange={handleChange}
        />
      </div>
      {/* <div>
        {result.map(r => (
          <div key={r.name}>{r.name}</div>
        ))}
      </div> */}
      <Main />
    </div>
  );
}
