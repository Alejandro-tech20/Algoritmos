import React from "react";
import { Form, Row, Col, Input, Button } from "antd";
// import {} from "@ant-design/icons";

export const AddActions = ({ onSubmit }) => {
  const [form] = Form.useForm();
  const onFinish = () => {
    onSubmit({
      id: form.getFieldValue("id"),
      name: form.getFieldValue("name")
    });
    form.resetFields();
  };

  return (
    <Form form={form} onFinish={onFinish} layout="horizontal">
      <Row gutter={20}>
        <Col>
          <Form.Item
            name={"name"}
            //rules={{ required: true, message: "This field is required" }}
          >
            <Input placeholder="Enter Actions" />
          </Form.Item>
          <Form.Item name={"id"}>
            <Input placeholder="Id" />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            ADD Actions
          </Button>
        </Col>
      </Row>
    </Form>
  );
};
