import React from 'react'
import { Row, Col, Table } from 'antd'

export const ListActions = ({data}) => {

  return (
    <Row typeof='flex' justify='center'>
      <Col>
      <Table dataSource={data} columns={4}/>
      </Col>
    </Row>
  )
}