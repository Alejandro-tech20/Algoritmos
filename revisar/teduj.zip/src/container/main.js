import React from "react";
import { Provider } from "react-redux";
import { store } from "../store/store";
import { Initial } from "./initial";

export const Main = () => {
  return (
    <Provider store={store}>
      <Initial />
    </Provider>
  );
};
