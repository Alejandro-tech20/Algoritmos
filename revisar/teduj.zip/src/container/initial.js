import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addActions, removeActions } from "../store/actions";
export const Initial = () => {
  const [value, setValue] = useState({
    id: "",
    name: "",
    completed: false
  });
  const actions = useSelector(ele => ele);
  const dispatch = useDispatch();
  const handleValue = e => {
    const t = e.target;
    setValue({
      ...value,
      [t.name]: t.value
    });
  };
  const handleAction = e => {
    e.preventDefault();
    dispatch(addActions(value));
    setValue({ id: "", name: "", completed: false });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          onChange={handleValue}
          value={value.name}
        />
        <input
          type="text"
          name="id"
          placeholder="ID"
          onChange={handleValue}
          value={value.id}
        />
        <input
          type="text"
          name="completed"
          placeholder="Completed"
          onChange={handleValue}
          value={value.completed}
        />
        <button type="submit" onClick={e => handleAction(e)}>
          Agregar
        </button>
      </div>
      <div style={{ display: "flex", flexDirection: "column" }}>
        {actions}
        {/* {actions.map(item => (
          <div
            style={{ display: "flex", flexDirection: "column" }}
            key={item.id}
          >
            <div> {`El Id: ${item.id}`} </div>
            <div> {`Name: ${item.name}`} </div>
          </div>
        ))} */}
      </div>
    </div>
  );
};
